# -*- coding: utf-8 -*-
"""
C3 AdBlock 本地刷机服务器。

为什么需要它：ESP Web Tools（浏览器刷固件）依赖 Web Serial API，
浏览器只在「安全上下文」下才允许访问串口。https:// 需要证书，
但 http://127.0.0.1（localhost）本身就是安全上下文，所以本地起个
静态服务器就够了 —— 不需要 HTTPS、不需要装任何工具链。

用法：双击「启动刷写.bat」，或在本目录执行  python serve.py
"""
import http.server
import os
import socket
import socketserver
import sys
import threading
import webbrowser

PORT = 8000
DIR = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIR, **kwargs)

    def log_message(self, fmt, *args):
        pass  # 安静一点，别刷屏


def port_busy(port):
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def main():
    url = f"http://127.0.0.1:{PORT}/"
    auto_open = "--no-browser" not in sys.argv

    if port_busy(PORT):
        print(f"端口 {PORT} 已被占用 —— 可能已经启动过了。")
        print(f"直接用 Chrome / Edge 打开：{url}")
        if auto_open:
            webbrowser.open(url)
        return

    socketserver.TCPServer.allow_reuse_address = True
    httpd = socketserver.TCPServer(("127.0.0.1", PORT), Handler)

    print("=" * 60)
    print("  C3 AdBlock 本地刷机服务器已启动")
    print()
    print(f"  用 Chrome / Edge 打开：  {url}")
    print()
    print("  1. ESP32-C3 用数据线插好")
    print("  2. 点页面上的「连接并安装」，选对应 COM 口")
    print("  3. 等它写完（约 30 秒），别拔线")
    print()
    print("  刷完固件后可以直接关掉这个窗口。")
    print("=" * 60)

    threading.Timer(1.0, lambda: webbrowser.open(url)).start() if auto_open else None
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    sys.exit(main())
