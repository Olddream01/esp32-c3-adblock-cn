# -*- coding: utf-8 -*-
"""
看串口日志 —— 用来确认 WiFi 到底存住没有。

ESP32-C3 SuperMini 用的是原生 USB-Serial-JTAG，插上就是��个 COM 口，
Windows 10/11 自带驱动，不用装 CH340。

用法：
    python 看日志.py            # 自动选第一个串口
    python 看日志.py COM7       # 指定串口
刷机之后跑这个，能看到关键的几行：
    WiFi: connecting to "你的WiFi" (provisioned) (attempt 1/3)   <- 用了 NVS/备份里的配置
    WiFi up: 192.168.x.x
    upstream DNS: 119.29.29.29:53
    [wifi] restored creds from LittleFS backup: xxx               <- NVS 丢了，从备份救回来
    [setup] BOOT held 3s -> cleared saved WiFi                    <- 误触清空
"""
import sys
import time

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    print("缺少 pyserial，先执行： python -m pip install pyserial")
    sys.exit(1)


def pick_port():
    if len(sys.argv) > 1:
        return sys.argv[1]
    ports = list(list_ports.comports())
    if not ports:
        return None
    # 优先挑 Espressif / USB JTAG 串口
    for p in ports:
        desc = f"{p.description} {p.hwid}".lower()
        if "espressif" in desc or "jtag" in desc or "303a" in desc:
            return p.device
    return ports[0].device


def main():
    port = pick_port()
    if not port:
        print("没找到串口。检查：")
        print("  1. 板子插好了吗？用的是数据线不是充电线？")
        print("  2. 设备管理器里有没有 COM 口？")
        print("  3. 换一个 USB 口（别用 USB 集线器）")
        return

    print(f"打开串口 {port} @ 115200 —— 按 Ctrl+C 结束")
    print("（想看开机日志的话，先拔掉板子再插上，或者按一下 RST）")
    print("-" * 60)
    try:
        ser = serial.Serial(port, 115200, timeout=1)
    except Exception as e:
        print(f"打开失败：{e}")
        print("如果提示被占用，先关掉 Arduino IDE / 串口助手 / PlatformIO Monitor。")
        return

    try:
        while True:
            line = ser.readline()
            if line:
                sys.stdout.write(line.decode("utf-8", "replace"))
                sys.stdout.flush()
            else:
                time.sleep(0.05)
    except KeyboardInterrupt:
        print("\n已退出。")
    finally:
        ser.close()


if __name__ == "__main__":
    main()
